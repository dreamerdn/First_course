public class TicketsQueue {
    int cnt;
    public TicketsQueue (int cnt){
        this.cnt=cnt;
    }
    // public boolean getBusy(){return busy;}
    // public void setBusy(boolean busy){this.busy=busy;}
    public int getCnt(){
        return cnt;
    }
    public void setCnt(int cnt){
        this.cnt=cnt;
    }
}
